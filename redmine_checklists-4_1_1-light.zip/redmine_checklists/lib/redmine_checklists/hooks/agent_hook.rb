# This file is a part of Redmine Checklists (redmine_checklists) plugin,
# issue checklists management plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_checklists is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_checklists is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_checklists.  If not, see <http://www.gnu.org/licenses/>.

# frozen_string_literal: true

module RedmineChecklists
  module Hooks
    class AgentHook < Redmine::Hook::Listener
      PROPERTIES = {
        checklists_attributes: {
          type: 'array',
          description: 'Checklist items in the REST API shape: items without id are added, with id are updated, _destroy removes one; subject is required for every item, also when updating.',
          items: {type: 'object', properties: {id: {type: 'integer'}, subject: {type: 'string'}, is_done: {type: 'boolean'},
                                               is_section: {type: 'boolean'}, position: {type: 'integer'}, _destroy: {type: 'boolean'}}}
        }
      }.freeze

      def agent_context_issue(context)
        {checklists: items(context[:actor], context[:record])}
      end

      def agent_mcp_arguments(context)
        return unless RedmineupAgent.allowed?(context[:user], [:edit_checklists, :done_checklists], context[:project])

        items = context[:args] && context[:args][:checklists_attributes]
        context[:args][:checklists_attributes] = items.each_with_index.to_h { |item, index| [index.to_s, item] } if items.is_a?(Array)
        PROPERTIES
      end

      def agent_mcp_result(context)
        issue = context[:record]
        return unless issue.is_a?(Issue) && context[:user].allowed_to?(:view_checklists, issue.project)

        issue.checklists.reload
        {checklists: items(context[:user], issue)}
      end

      private

      def items(user, issue)
        return unless user.allowed_to?(:view_checklists, issue.project)

        issue.checklists.map { |item| {id: item.id, subject: item.subject, is_done: item.is_done, is_section: item.is_section, position: item.position} }
      end
    end
  end
end

Rails.application.config.after_initialize { RedmineupAgent.register_mcp_scopes(:edit_checklists, :done_checklists, :view_checklists) if defined?(RedmineupAgent) }
