# This file is a part of Redmine Checklists (redmine_checklists) plugin,
# issue checklists management plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_checklists is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_checklists is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_checklists.  If not, see <http://www.gnu.org/licenses/>.

module RedmineChecklists
  module Patches
    module IssuesControllerPatch
      private

      def build_new_issue_from_params
        if params[:id].blank?
          begin
            if params[:copy_from].blank?
            else
              fill_checklist_attributes
            end
          rescue ActiveRecord::RecordNotFound
            render_404
            return
          end
        end
        super
        @issue.checklists_from_params = true
      end

      def fill_checklist_attributes
        return unless params[:issue].blank?

        @copy_from = Issue.visible.find(params[:copy_from])
        add_checklists_to_params(@copy_from.checklists)
      end

      def add_checklists_to_params(checklists)
        params[:issue].blank? ? params[:issue] = { :checklists_attributes => {} } : params[:issue][:checklists_attributes] = {}
        checklists.each_with_index do |checklist_item, index|
          params[:issue][:checklists_attributes][index.to_s] = {
            is_done: checklist_item.is_done,
            subject: checklist_item.subject,
            position: checklist_item.position,
            is_section: checklist_item.is_section
          }
        end
      end
    end
  end
end

IssuesController.prepend(RedmineChecklists::Patches::IssuesControllerPatch)
