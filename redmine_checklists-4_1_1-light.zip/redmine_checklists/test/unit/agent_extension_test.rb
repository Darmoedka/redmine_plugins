# encoding: utf-8
#
# This file is a part of Redmine Checklists (redmine_checklists) plugin,
# issue checklists management plugin for Redmine
#
# Copyright (C) 2011-2026 RedmineUP
# http://www.redmineup.com/
#
# redmine_checklists is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_checklists is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_checklists.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path('../../test_helper', __FILE__)

class AgentExtensionTest < ActiveSupport::TestCase
  fixtures :projects, :users, :email_addresses, :roles, :members, :member_roles, :issues, :issue_statuses, :trackers,
           :projects_trackers, :enabled_modules, :enumerations, :workflows, :journals, :journal_details

  load_plugin_fixtures :redmine_checklists, :checklists

  def setup
    skip 'redmineup_agent is not installed' unless Redmine::Plugin.installed?(:redmineup_agent)
    Setting.rest_api_enabled = '1'
    Role.find(1).add_permission! :edit_checklists
    Role.find(1).add_permission! :view_checklists
    @user = User.find(2)
  end

  def test_create_issue_with_checklists
    result = call_tool('create_issue', project: 'ecookbook', subject: 'With list',
                                       checklists_attributes: [{subject: 'one'}, {subject: 'two', is_done: true}])
    assert_equal %w[one two], result['checklists'].map { |item| item['subject'] }
    assert_equal [false, true], result['checklists'].map { |item| item['is_done'] }
  end

  def test_update_issue_changes_checklist
    created = call_tool('create_issue', project: 'ecookbook', subject: 'With list', checklists_attributes: [{subject: 'one'}, {subject: 'two'}])
    one, two = created['checklists']
    result = call_tool('update_issue', id: created['id'],
                                       checklists_attributes: [{id: one['id'], subject: 'one', is_done: true}, {id: two['id'], subject: 'two', _destroy: true}, {subject: 'three'}])
    assert_equal %w[one three], result['checklists'].map { |item| item['subject'] }
    assert_equal [true, false], result['checklists'].map { |item| item['is_done'] }
  end

  def test_get_issue_returns_checklists
    result = call_tool('get_issue', id: Checklist.first.issue_id)
    assert result['checklists'].any?
  end

  def test_get_issue_hides_checklists_without_view_permission
    Role.find(1).remove_permission! :view_checklists
    assert_not call_tool('get_issue', id: Checklist.first.issue_id).key?('checklists')
  end

  def test_checklists_are_ignored_without_permission
    Role.find(1).remove_permission! :edit_checklists
    result = call_tool('create_issue', project: 'ecookbook', subject: 'No list', checklists_attributes: [{subject: 'one'}])
    assert_equal 0, Issue.find(result['id']).checklists.count
  end

  def test_context_extension_contains_checklists_visible_to_the_user
    Role.find(1).add_permission! :view_checklists
    data = context(Checklist.first.issue)
    assert data[:checklists].any?
    Role.find(1).remove_permission! :view_checklists
    @user = User.find(2)
    assert_nil context(Checklist.first.issue.reload)[:checklists]
  end

  private

  def context(issue)
    RedmineupAgent.with_context_extensions({}, issue, @user, Struct.new(:context).new('issue_notes'))
  end

  def call_tool(name, arguments)
    result = RedmineupAgent::Mcp.with_credentials('HTTP_X_REDMINE_API_KEY' => @user.api_key) do
      RedmineupAgent::Mcp.call_tool({'name' => name, 'arguments' => arguments.deep_stringify_keys}, @user)
    end
    assert_not result[:isError], result.inspect
    json = JSON.parse(result[:content][0][:text])
    json['issue'] || json
  end
end
